package pdcassignment1;

/**
 *
 * @author evelt
 */

//Determines the difficulty of the questions
public enum Difficulty {
    EASY, MEDIUM, HARD, EXTRAHARD
}

